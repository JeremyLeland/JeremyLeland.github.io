/*
    SSSSS EEEEE CCCCC TTTTT OOOOO RRRRR     CCCCC 3333  77777
    S     E     C       T   O   O R   R     C         3     7
    SSSSS EEE   C       T   O   O RRRRR     C       33     7
        S E     C       T   O   O R RR      C         3   7
    SSSSS EEEEE CCCCC   T   OOOOO R   R     CCCCC 3333    7

                       by Dark_Iguana
*/

#include <allegro.h>
#include <stdio.h>
#include <conio.h>
#include "stars.h"
#include "ships.h"

// counters
volatile int menu_counter;
void inc_menu_counter()
{
  menu_counter++;
}
END_OF_FUNCTION(inc_menu_counter);
volatile int frame_counter;
void inc_frame_counter()
{
  frame_counter++;
}
END_OF_FUNCTION(inc_frame_counter);
// player bullet counter
volatile int pbullet_counter;
void inc_pbullet_counter()
{
  pbullet_counter++;
}
END_OF_FUNCTION(inc_pbullet_counter);
// enemy bullet counter
volatile int ebullet_counter;
void inc_ebullet_counter()
{
  ebullet_counter++;
}
END_OF_FUNCTION(inc_ebullet_counter);
// game over screen counter
volatile int death_counter;
void inc_death_counter()
{
  death_counter++;
}
END_OF_FUNCTION(inc_death_counter);

int main()
{
  // INITIALIZATION
  clrscr();
  textcolor(15);
  textbackground(2);
  gotoxy(1,1);
  cprintf("SECTOR C37  Version 1.0  (C) Dark_Iguana 2002-2003                              ");
  textbackground(0);
  gotoxy(1,2);
  cprintf("Initializing...");
  allegro_init();
  install_keyboard();
  install_timer();
  install_sound(DIGI_AUTODETECT,MIDI_AUTODETECT,0);
  text_mode(-1);

  // VARIABLES
  // the all important "for" variables, and other temps
  int t,r,s,a,b,c,d;
  // sounds
  gotoxy(1,3);
  cprintf("Loading sounds...");
  //SAMPLE *laser01=load_wav("lasergun.wav");
  // bitmaps
  gotoxy(1,4);
  cprintf("Loading images...");
  PALETTE pal;
  BITMAP *vscreen=create_bitmap(320,240);
  BITMAP *menuscreen=load_pcx("sectorc37.pcx",pal);
  BITMAP *master=load_pcx("ships.pcx",pal);
  BITMAP *hud=load_pcx("HUD.pcx",pal);
  BITMAP *ship_icon[3][4];        // 3 ship icons, plus death animation
  for(t=0;t<4;t++)
  {
    ship_icon[0][t]=create_bitmap(32,32); clear_bitmap(ship_icon[0][t]);
    ship_icon[1][t]=create_bitmap(32,17); clear_bitmap(ship_icon[1][t]);
    ship_icon[2][t]=create_bitmap(32,25); clear_bitmap(ship_icon[2][t]);
  }
  for(t=0;t<4;t++)
  {
    blit(master,ship_icon[0][t],0,t*32,0,0,32,32);
    blit(master,ship_icon[1][t],32,t*32,0,0,32,17);
    blit(master,ship_icon[2][t],64,t*32,0,0,32,25);
  }
  destroy_bitmap(master);
  // ships
  gotoxy(1,5);
  cprintf("Loading ship data...");
  const int NUM_ENEMIES=90;
  unsigned int playerscore;      // player's score
  int playerlives;               // lives player has left
  double playershields;
  ship player;
  player.setState(4);              // your ship
  player.setX(150);                // setting your ship data
  player.setY(200);
  player.setHp(500);
  player.setIcon(ship_icon[0][0]);
  //player.setThrusters(true);
  FILE *posfile=fopen("levels.c37","r");  // open up level file for reading
  // load start position info. info stored in format:
  // [level]:[ship#]:[x]:[y]:[type]
  // t is being used as a temporary variable
  fscanf(posfile,"#%d\n",&t);               // find number of levels
  int current_level=1;
  const int NUM_LEVELS=t;
  int startpos[NUM_LEVELS][NUM_ENEMIES][3];          // starpos[level][ship][x,y,icon]
  for(r=0;r<NUM_LEVELS*NUM_ENEMIES;r++)
  {
    fscanf(posfile,"%d:%d:%d:%d:%d",&a,&b,&c,&d,&s);
    startpos[a-1][b-1][0]=c; startpos[a-1][b-1][1]=d; startpos[a-1][b-1][2]=s;
  }
  ship enemy[NUM_ENEMIES];                  // set up slots for enemy ships
  // starfield
  starfield stars(0,0,0);
  // misc
  int choice=1; // variable used to store choice in menu
  bool game_won=false,game_lost=false; // variables store whether game has been won or lost
  // timer stuff
  LOCK_VARIABLE(frame_counter);
  LOCK_VARIABLE(menu_counter);
  LOCK_VARIABLE(pbullet_counter);
  LOCK_VARIABLE(ebullet_counter);
  LOCK_VARIABLE(death_counter);

  LOCK_FUNCTION((void*)inc_frame_counter);
  LOCK_FUNCTION((void*)inc_menu_counter);
  LOCK_FUNCTION((void*)inc_pbullet_counter);
  LOCK_FUNCTION((void*)inc_ebullet_counter);
  LOCK_FUNCTION((void*)inc_death_counter);
  
  install_int_ex(inc_frame_counter, BPS_TO_TIMER(40));
  install_int_ex(inc_menu_counter, BPS_TO_TIMER(10));
  install_int_ex(inc_pbullet_counter, BPS_TO_TIMER(20));
  install_int_ex(inc_ebullet_counter, BPS_TO_TIMER(15));

  int frame_delay=frame_counter;
  int menu_delay=menu_counter;
  int pbullet_delay=pbullet_counter;
  int ebullet_delay=ebullet_counter;
  int death_delay;

  gotoxy(1,6);
  cprintf("Initialization complete.");
  gotoxy(1,7);
  cprintf("Press any key to enter Sector C37...");
  readkey();
  // BEGIN GAME
  set_gfx_mode(GFX_SAFE,320,240,0,0);
  set_palette(pal);
  menu:
  while(1==1)
  {
    if(frame_counter>frame_delay)
    {
      frame_delay=frame_counter;
      // funky colored lines
      for(r=0;r<240;r++)
      {
        line(vscreen,0,r,320,r,makecol((rand()%20)+235,(rand()%150)+50,0));
      }
      draw_sprite(vscreen,menuscreen,0,0);
      switch(choice)
      {
        case 1:
          line(vscreen,60,90,270,90,makecol(255,0,23));
          line(vscreen,60,90,60,120,makecol(255,0,23));
          line(vscreen,60,120,270,120,makecol(255,0,23));
          line(vscreen,270,90,270,120,makecol(255,0,23));
          break;
        case 2:
          line(vscreen,60,130,270,130,makecol(255,0,23));
          line(vscreen,60,130,60,170,makecol(255,0,23));
          line(vscreen,60,170,270,170,makecol(255,0,23));
          line(vscreen,270,130,270,170,makecol(255,0,23));
          break;
        case 3:
          line(vscreen,60,175,270,175,makecol(255,0,23));
          line(vscreen,60,175,60,210,makecol(255,0,23));
          line(vscreen,60,210,270,210,makecol(255,0,23));
          line(vscreen,270,175,270,210,makecol(255,0,23));
          break;
      }
      blit(vscreen,screen,0,0,0,0,320,240);
      if(menu_counter>menu_delay)
      {
        menu_delay=menu_counter;
        if(key[KEY_UP])
        {
          choice--; if(choice==0) {choice=3;}
        }
        if(key[KEY_DOWN])
        {
          choice++; if(choice==4) {choice=1;}
        }
      }
      if(key[KEY_ENTER])
      {
        if(choice==1) {goto game;}
        if(choice==2) {goto howtoplay;}
        if(choice==3) {goto end;}
      }
    }
  }
  howtoplay:
  clear_bitmap(vscreen);
  // draw HUD
  draw_sprite(vscreen,hud,0,0);
  textprintf_centre(vscreen,font,160,20,makecol(255,255,23),"This is your Heads-Up Display, or HUD.");
  textprintf_centre(vscreen,font,160,30,makecol(255,255,23),"It tells you which wave (level) you");
  textprintf_centre(vscreen,font,160,40,makecol(255,255,23),"are on, your current score, how many");
  textprintf_centre(vscreen,font,160,50,makecol(255,255,23),"lives you have left, and how strong");
  textprintf_centre(vscreen,font,160,60,makecol(255,255,23),"your shields are.");
  // your ship
  draw_sprite(vscreen,ship_icon[0][0],0,75);
  textprintf_centre(vscreen,font,180,80,makecol(255,255,23),"This is your ship. You move it with");
  textprintf_centre(vscreen,font,180,90,makecol(255,255,23),"the arrow keys, and shoot with the");
  textprintf_centre(vscreen,font,180,100,makecol(255,255,23),"spacebar.");
  // enemy ships
  draw_sprite(vscreen,ship_icon[1][0],0,115);
  draw_sprite(vscreen,ship_icon[2][0],0,135);
  textprintf_centre(vscreen,font,180,125,makecol(255,255,23),"These are the enemy ships. Shoot");
  textprintf_centre(vscreen,font,180,135,makecol(255,255,23),"these for points. They shoot back,");
  textprintf_centre(vscreen,font,180,145,makecol(255,255,23),"so try not to get hit!");
  textprintf_centre(vscreen,font,160,180,makecol(255,255,23),"That's all there is to it! Now,");
  textprintf_centre(vscreen,font,160,190,makecol(255,255,23),"GO GET 'EM, TIGER!!!");
  blit(vscreen,screen,0,0,0,0,320,240);
  while(!key[KEY_ESC]){}
  goto menu;
  game:
  game_won=false;
  game_lost=false;
  // reset variables that need reseting
  // death clock
  death_delay=death_counter;
  // enemy starting positions (place here so that it's a new game each time
  // you click "start", rather than resuming a won (or lost) game
  for(r=0;r<NUM_ENEMIES;r++)                // assign enemy ships to their starting
  {                                         // positions
    enemy[r].setState(4);
    enemy[r].setX(startpos[0][r][0]);
    enemy[r].setY(startpos[0][r][1]);
    enemy[r].setHp(50*startpos[0][r][2]);
    enemy[r].setType(startpos[0][r][2]);
    enemy[r].setIcon(ship_icon[enemy[r].type()][4-enemy[r].state()]);
    //enemy[(5*r)+t].setThrusters(false);
  }
  for(t=0;t<80;t++)
  {
    player.setBulletActive(t,false);
  }
  current_level=1;
  playerscore=0;
  playerlives=4;
  player.setState(4);
  player.setX(150);                // resetting your ship data
  player.setY(200);
  player.setHp(500);
  player.setIcon(ship_icon[0][0]);
  //player.setThrusters(true);
  while(!key[KEY_ESC])
  {
    if(frame_counter>frame_delay)
    {
      frame_delay=frame_counter;
      // DRAW SCREEN
      // starfield
      stars.update();
      for(r=0;r<stars.layers();r++)
      {
        for(t=0;t<stars.num_stars();t++)
        {
          putpixel(vscreen,stars.x(r,t),stars.y(r,t),makecol(200+(r*20),200+(r*20),200+(r*20)));
        }
      }
      // enemy ships
      for(r=0;r<NUM_ENEMIES;r++)
      {
        if(enemy[r].y()>-32 && enemy[r].state()>0)
        {
          if(enemy[r].state()==4)
          {
            //for(t=0;t<50;t++)
            //{
            //  putpixel(vscreen,player.thrusters.x(t),player.thrusters.y(t),makecol(100,100,0);
            //}
            //draw_sprite(vscreen,enemy[r].icon(),enemy[r].x(),enemy[r].y());
            draw_sprite(vscreen,ship_icon[enemy[r].type()][4-enemy[r].state()],enemy[r].x(),enemy[r].y());
            //enemy[r].thrusters.update(enemy[r].x(),enemy[r].y());
          }
          else if(enemy[r].state()>0)
          {
            draw_sprite(vscreen,ship_icon[enemy[r].type()][4-enemy[r].state()],enemy[r].x(),enemy[r].y());
            enemy[r].setState(enemy[r].state()-1);
            if(enemy[r].state()==0) {playerscore+=(5*enemy[r].type());}
          }
        }
        for(t=0;t<80;t++)
        {
          if(enemy[r].bulletactive(t))
          {
            putpixel(vscreen,enemy[r].bulletx(t),enemy[r].bullety(t),makecol(0,200,23));
          }
        }
      }
      // your ship
      if(player.state()==4)
      {
        //for(t=0;t<50;t++)
        //{
        //  putpixel(vscreen,player.thrusters.x(t),player.thrusters.y(t),makecol(100,100,0);
        //}
        for(t=0;t<80;t++)
        {
           if(player.bulletactive(t)==true)
          {
            putpixel(vscreen,player.bulletx(t),player.bullety(t),makecol(200,0,23));
          }
        }
        draw_sprite(vscreen,player.icon(),player.x(),player.y());
        //player.thrusters.update(player.x(),player.y());
        player.update_bullets(false);
      }
      else if(player.state()>0)
      {
        draw_sprite(vscreen,ship_icon[0][4-player.state()],player.x(),player.y());
        player.setState(player.state()-1);
        if(player.state()==0)
        {
          playerlives--;
          if(playerlives>=0)
          {
            player.setState(4);
            player.setX(150);                // resetting your ship data
            player.setY(200);
            player.setHp(500);
            player.setIcon(ship_icon[0][0]);
            //player.setThrusters(true);
          }
          else
          {
            // create death counter, so that player can see "game over" for
            // a little while before going back to menu
            install_int_ex(inc_death_counter,SECS_TO_TIMER(3));
            death_delay=death_counter;
            game_lost=true;
            playerlives=0; //so the lives thingy on HUD doesn't say -1
          }
        }
      }
      // HUD
      // reuse "s" variable for shields
      playershields=int(100*(double(player.hp())/500));
      s=playershields;
      textprintf(vscreen,font,42,2,3,"%d",current_level);
      textprintf(vscreen,font,114,2,72,"%d",playerscore);
      textprintf(vscreen,font,197,2,50,"%d",playerlives);
      textprintf(vscreen,font,283,2,48,"%d",s);
      draw_sprite(vscreen,hud,0,0);
      // win text (placed here for drawing order)
      if(game_won)
      {
        textprintf_centre(vscreen,font,160,20,makecol(255,255,23),"Congradulations, Pilot! You have");
        textprintf_centre(vscreen,font,160,40,makecol(255,255,23),"cleansed the sector, and brought peace");
        textprintf_centre(vscreen,font,160,60,makecol(255,255,23),"and order to its inhabitants. Command");
        textprintf_centre(vscreen,font,160,80,makecol(255,255,23),"issued the following statement regarding");
        textprintf_centre(vscreen,font,160,100,makecol(255,255,23),"your actions: \"We applaud the work of");
        textprintf_centre(vscreen,font,160,120,makecol(255,255,23),"the unnamed pilot who came to the rescue");
        textprintf_centre(vscreen,font,160,140,makecol(255,255,23),"of those in need. His actions have");
        textprintf_centre(vscreen,font,160,160,makecol(255,255,23),"brought peace and prosperity to Sector");
        textprintf_centre(vscreen,font,160,180,makecol(255,255,23),"C37. We salute his actions, and hope to");
        textprintf_centre(vscreen,font,160,200,makecol(255,255,23),"work with him more in the future.\"");
      }
      if(game_lost)
      {
        textprintf_centre(vscreen,font,160,120,makecol(255,255,23),"GAME OVER");
      }
      // FINAL BLIT
      blit(vscreen,screen,0,0,0,0,320,240);
      clear_bitmap(vscreen);
      // MOVEMENT
      // enemy ships
      for(r=0;r<NUM_ENEMIES;r++)
      {
        enemy[r].setY(enemy[r].y()+2);
      }
      if(ebullet_counter>ebullet_delay)
      {
        ebullet_delay=ebullet_counter;
        // check if player is infront of ship. if so, fire
        for(r=0;r<NUM_ENEMIES;r++)
        {
          if(enemy[r].state()==4)
          {
            if(enemy[r].y()>-32 && enemy[r].y()<240 && player.state()==4 &&
               player.x()>=enemy[r].x()-31 && player.x()<=enemy[r].x()+32 &&
               player.y()>enemy[r].y())
            {
              enemy[r].makeBullet(enemy[r].x()+2,enemy[r].y(),true);
              enemy[r].makeBullet(enemy[r].x()+30,enemy[r].y(),true);
            }
          }
        }
      }
      // your ship
      if(!game_lost)
      {
        if(key[KEY_UP] && player.y()-3>0)      {player.setY(player.y()-3);}
        if(key[KEY_DOWN] && player.y()+3<208)  {player.setY(player.y()+3);}
        if(key[KEY_LEFT] && player.x()-3>0)    {player.setX(player.x()-3);}
        if(key[KEY_RIGHT] && player.x()+3<288) {player.setX(player.x()+3);}
        if(pbullet_counter>pbullet_delay)
        {
          pbullet_delay=pbullet_counter;
          if(key[KEY_SPACE])
          {
             player.makeBullet(player.x()+2,player.y(),false);
             player.makeBullet(player.x()+30,player.y(),false);
             //play_sample(laser01,100,(player.x()/320)*255,1000,0);
          }
        }
      }
      // collision detection
      // ship collision
      // for each of the ships, check to see if they are colliding with player
      // if so, take the shields of the other away from each. ie: if enemy has
      // 30 shields left and player has 50 shields left, the result of the collision
      // would be -20 shields for enemy and 30 for player
      for(r=0;r<NUM_ENEMIES;r++)
      {
        if(enemy[r].state()==4 && player.state()==4 &&
           player.x()>=enemy[r].x()-32 && player.x()<=enemy[r].x()+32 &&
           player.y()>=enemy[r].y()-32 && player.y()<=enemy[r].y()+32)
        {
          // store difference in the randomly selected "s" varialbe
          s=player.hp();
          t=enemy[r].hp();
          enemy[r].setHp(t-s);
          player.setHp(s-t);
          // if enemy's dead, activate animation for death
          if(enemy[r].hp()<=0)
          {
            enemy[r].setState(enemy[r].state()-1);
          }
          // if it ain't dead yet, show some shieldage
          else
          {
            ellipse(vscreen,enemy[r].x()+16,enemy[r].y()+9,18,18,makecol(20,20,200));
          }
          // if player's dead, activate animation for death
          if(player.hp()<=0)
          {
            player.setState(player.state()-1);
          }
          // if it ain't dead yet, show some shieldage
          else
          {
            ellipse(vscreen,player.x()+16,player.y()+9,18,18,makecol(20,20,200));
          }
        }
      }
      // player bullets
      // for each of the 80 bullets, check to see if it collides with any of
      // the ships
      for(t=0;t<80;t++)
      {
        for(r=0;r<NUM_ENEMIES;r++)
        {
          if(player.bulletactive(t))
          {
            if(enemy[r].state()==4 && player.state()==4 &&
               player.bulletx(t)>=enemy[r].x() &&
               player.bulletx(t)<=enemy[r].x()+32 &&
               player.bullety(t)>=enemy[r].y() &&
               player.bullety(t)<=enemy[r].y()+32)
            {
              player.setBulletActive(t,false);
              enemy[r].setHp(enemy[r].hp()-7);
              // if it's dead, activate animation for death
              if(enemy[r].hp()<=0)
              {
                enemy[r].setState(enemy[r].state()-1);
              }
              // if it ain't dead yet, show some shieldage
              else
              {
                ellipse(vscreen,enemy[r].x()+16,enemy[r].y()+9,18,18,makecol(20,20,200));
              }
            }
          }
        }
        if(player.bulletactive(t))
        {
          if(player.bullety(t)<0) {player.setBulletActive(t,false);}
        }
      }
      // ship bullets
      // for each of the ships, check to see if any of the 80 bullets
      // collides with player ship
      for(r=0;r<NUM_ENEMIES;r++)
      {
        for(t=0;t<80;t++)
        {
          if(enemy[r].bulletactive(t))
          {
            if(player.state()==4 &&
               enemy[r].bulletx(t)>=player.x() &&
               enemy[r].bulletx(t)<=player.x()+32 &&
               enemy[r].bullety(t)>=player.y() &&
               enemy[r].bullety(t)<=player.y()+32)
            {
              enemy[r].setBulletActive(t,false);
              player.setHp(player.hp()-(enemy[r].type()*1));
              //if(enemy[r].hp()<=0) {enemy[r].setState(enemy[r].state()-1);}
              if(player.hp()<=0) {player.setState(player.state()-1);}
              else
              {
                ellipse(vscreen,player.x()+16,player.y()+16,18,18,makecol(20,20,200));
              }
            }
            if(enemy[r].bullety(t)>240) {enemy[r].setBulletActive(t,false);}
          }
        }
        enemy[r].update_bullets(true);
      }
      // check for end of level
      // if last ship is off the screen, level is over
      if(enemy[NUM_ENEMIES-1].y()>240)
      {
        if(current_level<NUM_LEVELS)
        {
          current_level++;
          // set ships to next level starting possitions, with full hp
          for(r=0;r<NUM_ENEMIES;r++)                // assign enemy ships to their starting
          {                                         // positions
            enemy[r].setState(4);
            enemy[r].setX(startpos[current_level-1][r][0]);
            enemy[r].setY(startpos[current_level-1][r][1]);
            enemy[r].setHp(50*startpos[current_level-1][r][2]);
            enemy[r].setType(startpos[current_level-1][r][2]);
            enemy[r].setIcon(ship_icon[enemy[r].type()][4-enemy[r].state()]);
            for(t=0;t<80;t++)
            {
              enemy[r].setBulletActive(t,false);
            }
            //enemy[(5*r)+t].setThrusters(false);
          }
        }
        else{game_won=true;}
      }
      if(death_counter>death_delay)
      {
        remove_int(inc_death_counter);
        goto menu;
      }
    }
  }
  goto menu;
  // END GAME
  end:
  set_gfx_mode(GFX_TEXT,0,0,0,0);
  destroy_bitmap(vscreen);
  clrscr();
  gotoxy(1,1);
  cprintf("Thank you for playing Sector C37!!!");
  gotoxy(1,2);
  cprintf("(C) Dark_Iguana 2003");
  gotoxy(1,3);
  cprintf("http://www.geocities.com/iggames13/");
  gotoxy(1,5);
}
END_OF_MAIN();
