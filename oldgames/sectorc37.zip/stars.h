// stars.h
// starfield class

#ifndef STARS_H
#define STARS_H

#include <stdio.h>
#include <time.h>

class starfield
{
  public:
    starfield(int layers, int num_stars, int color);
    int x(int layer, int star);
    int y(int layer, int star);
    int layers();
    int num_stars();
    int color();
    void update();
  private:
    int myT;
    int myR;
    int myLayers;
    int myNum_stars;
    int myColor;
    int myStar[3][100][2];
};

starfield::starfield(int layers, int num_stars, int color)
{
  int rand_shiet;           // variable not declared, likely will be random
  srand(rand_shiet);
  myLayers=3;
  myNum_stars=100;
  myColor=color;
  // int myStar[layers][num_stars][2];
  for(myR=0;myR<myLayers;myR++)
  {
    for(myT=0;myT<myNum_stars;myT++)
    {
      myStar[myR][myT][0]=rand()%320;
      myStar[myR][myT][1]=rand()%240;
    }
  }
}

int starfield::x(int layer, int star)
{
  return myStar[layer][star][0];
}
int starfield::y(int layer, int star)
{
  return myStar[layer][star][1];
}
int starfield::color()
{
  return myColor;
}
int starfield::layers()
{
  return myLayers;
}
int starfield::num_stars()
{
  return myNum_stars;
}

void starfield::update()
{
  for(myR=0;myR<myLayers;myR++)
  {
    for(myT=0;myT<myNum_stars;myT++)
    {
      myStar[myR][myT][1]+=myR+1;
      if(myStar[myR][myT][1]>240)
      {
        //srand(rawclock()/2);
        myStar[myR][myT][0]=rand()%320;
        myStar[myR][myT][1]=rand()%3;
      }
    }
  }
}
#endif
