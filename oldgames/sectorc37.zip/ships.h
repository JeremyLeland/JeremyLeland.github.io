// ships.h
// ship classes

#ifndef SHIPS_H
#define SHIPS_H

#include <allegro.h>
#include <stdlib.h>
#include <time.h>
//#include "engine.h"

class ship
{
  public:
    ship();
    int state();   // state of 4=alive,3-1=exploding,0=dead
    int x();
    int y();
    double hp();
    int weapon();
    int type();
    BITMAP *icon();
    //engine thrusters();
    int bulletx(int bullet);
    int bullety(int bullet);
    bool bulletactive(int bullet);
    void setState(int newState);
    void setX(int newX);
    void setY(int newY);
    void setHp(double newHp);
    void setWeapon(int newWeapon);
    void setType(int newType);
    void setIcon(BITMAP *newIcon);
    void setBulletActive(int bullet, bool torf);
    //void setEngine(bool direction);
    void makeBullet(int shipx, int shipy, bool shipdir);
    void update_bullets(bool shipdir);
  private:
    int myState;
    int myX;
    int myY;
    double myHp;
    int myWeapon;
    int myType;
    BITMAP *myIcon;
    SAMPLE *myLaser01;
    //engine myThrusters(false);
    int myBullet[80][2];
    bool myBulletActive[80];
};

ship::ship()
{
  myState=0;
  myX=0;
  myY=0;
  myHp=0;
  myWeapon=0;
  myType=0;
  for(int t=0;t<80;t++)
  {
    myBulletActive[t]=false;
    myBullet[t][0]=0;
    myBullet[t][1]=0;
  }
  myLaser01=load_wav("lasergun.wav");
  myIcon=create_bitmap(32,32);
  clear_bitmap(myIcon);
}
int ship::state()
{
  return myState;
}
int ship::x()
{
  return myX;
}
int ship::y()
{
  return myY;
}
double ship::hp()
{
  return myHp;
}
int ship::weapon()
{
  return myWeapon;
}
int ship::type()
{
  return myType;
}
BITMAP *ship::icon()
{
  return myIcon;
}
//engine ship::thrusters()
//{
//  return myThrusters;
//}
int ship::bulletx(int bullet)
{
  return myBullet[bullet][0];
}
int ship::bullety(int bullet)
{
  return myBullet[bullet][1];
}
bool ship::bulletactive(int bullet)
{
  return myBulletActive[bullet];
}
void ship::setState(int newState)
{
  myState=newState;
}
void ship::setX(int newX)
{
  myX=newX;
}
void ship::setY(int newY)
{
  myY=newY;
}
void ship::setHp(double newHp)
{
  myHp=newHp;
}
void ship::setWeapon(int newWeapon)
{
  myWeapon=newWeapon;
}
void ship::setType(int newType)
{
  myType=newType;
}
void ship::setIcon(BITMAP *newIcon)
{
  draw_sprite(myIcon,newIcon,0,0);
}
//void ship::setThrusters(bool direction)
//{
//  myThrusters.setDirection(direction);
//}
void ship::setBulletActive(int bullet,bool torf)
{
  myBulletActive[bullet]=torf;
}
void ship::makeBullet(int shipx, int shipy, bool shipdir)
// searches for empty bullet slot
{
  int temp=-1;   // stores number of open slot
  int t;
  for(t=79;t>=0;t--)
  {
    if(myBulletActive[t]==false) {temp=t;}
  }
  if(temp>=0)       // check that an empty slot was found
  {
    play_sample(myLaser01,100,(myX/320)*255,850,0);
    myBulletActive[temp]=true;
    myBullet[temp][0]=shipx;
    if(!shipdir) {myBullet[temp][1]=shipy+10;}
    if(shipdir)
    {
      if(myType==1) {myBullet[temp][1]=shipy+4;}
      if(myType==2) {myBullet[temp][1]=shipy+15;}
    }
  }
}
void ship::update_bullets(bool shipdir)
// simple updating, moves bullets and sets their status
// to non-active if they go offscreen
{
  int t;
  if(shipdir==false)
  {
    for(t=0;t<80;t++)
    {
      if(myBulletActive[t]==true)
      {
        myBullet[t][1]-=7;
      }
    }
  }
  else
  {
    for(t=0;t<80;t++)
    {
      if(myBulletActive[t]==true)
      {
        if(myType==1) {myBullet[t][1]+=5;}
        if(myType==2) {myBullet[t][1]+=4;}
      }
    }
  }
}
#endif
